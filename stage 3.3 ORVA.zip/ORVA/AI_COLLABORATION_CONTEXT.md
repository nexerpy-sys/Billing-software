# ORVA — authoritative handoff context for external coding models

## Product and owner/staff requirements

- Product name: **ORVA**. Publisher/parent brand: **Rindle Works**. Working tagline/category: Pharmacy Billing & Inventory.
- ORVA is intended to become a reusable commercial Windows product for multiple independent medical shops. Every installation is configured for one shop and has its own local database and shop data. Do not create a multi-tenant shared customer database.
- Current V1 is **Windows-only**. The client explicitly cancelled the Android application and device synchronisation. Do not add Android, Flutter, cloud business-data hosting, LAN sync, device pairing, or sync event queues.
- Target laptop is Windows 10. Current engineering baseline: C# 7.3, WPF, .NET Framework 4.8.1, System.Data.SQLite.Core 1.0.119, SQLite. This compatibility choice must be tested on the client's exact Windows 10 edition/build before release.
- Database and backups are deliberately **unencrypted**. Do not add SQLCipher, encryption keys, TLS/certificate/key-management work, or encrypted archives. Ordinary operating-system file permissions and normal backups are sufficient for the agreed threat model.
- The actual owner and staff must be able to use ORVA with little technical knowledge. This is a core requirement: minimise typing, choices, setup prompts and waiting; use professional but clear English and Bengali; icons must have text; readable controls; natural error messages; no technical jargon in staff-facing UI. Never add a workflow merely because it is technically possible.
- No routine login, no staff accounts, no roles and no permissions. The product subscription account is a separate licensing concern; do not add employee access control.

## Brand and visual direction

- Warm paper `#F3EADA`; deep charcoal teal `#172C30`; ink `#1A1712`; vermilion `#FF4B1F`.
- No warm amber and no dark mode.
- Print-inspired editorial style with architectural rules, restrained two-ink overprint, subtle paper grain only on decorative surfaces, and the scalloped/perforated vermilion ticket edge as a selective signature motif.
- Functional medicine grids, invoice tables and entry forms must remain clear, solid and readable. Animations must never delay a transaction.

## Functional decisions already made

- Medicine catalogue plus batch-wise inventory. Each batch has its own batch number, expiry month, MRP, purchase cost and quantity.
- Stock unit is defined per medicine. Do not invent unit conversion/pack-size conversion logic unless specifically requested.
- Automatic FEFO batch allocation is desired for sales. Expired, quarantined, blocked or otherwise non-sellable stock must not be sold.
- Every committed business operation has an automatic UTC timestamp and local-display timestamp. Staff never type timestamps.
- Every stock change must be represented by a stock movement record. The database is the source of truth.
- Medicine search and recognised existing barcodes are supported; Windows uses USB barcode scanners with manual search fallback. Do not add staff-facing barcode registration or barcode-generation screens.
- Payment methods: CASH, UPI, DEBIT_CARD, CREDIT_CARD. Split payment is supported. Do not add generic "Other". For a fully paid invoice, tender amounts must exactly equal the payable amount.
- Returns are linked to original invoices. Returned medicine goes into quarantine by default; it must not automatically become sellable. Damaged/expired items cannot return to sellable stock.
- Invoice paper formats: 58 mm, 80 mm, A4 and A5.
- Customer name, phone, address and GSTIN are optional for ordinary billing; request legally necessary data only in applicable cases.
- Purchase flow should be simple. Real-world supplier/document records must be retained accurately. Do not fabricate invoices or claim input tax credit eligibility for undocumented purchases. Tax/legal treatment requires CA/pharmacist review.
- ITR support means preserving and exporting accurate records; do not claim to calculate/file the whole ITR.
- No unnecessary sales/profit dashboard. Preserve the underlying invoice, payment, purchase, returns, stock movement and audit records.

## Portable data files

The application uses a shop-named folder under the owner's Documents/data location.

1. `StockData.json`: generated automatically from the authoritative database. It is a complete snapshot of current medicine catalogue and batch inventory, not a full backup. It may be imported to replace current inventory only after validation, preview, pre-import backup and explicit confirmation. Never delete invoices, payment, purchase, return, or audit history when importing stock. Keep historical medicine/batch rows when foreign-key history depends on them; represent quantity differences using stock adjustments/movements.
2. `ShopBackup.shopbackup`: separate one-file complete shop backup containing all business records and required metadata. Restore only after validation, preview, safety backup and confirmation.

Both files are unencrypted. Snapshot writing currently uses a temporary file and replacement. Do not make these files the live database or silently overwrite historical records.

## Subscription direction (not part of either coding assignment)

- Commercial product is intended to offer monthly, quarterly, annual and one-time licence options.
- Manual UPI payment review through WhatsApp is planned.
- A public GitHub repository containing only a minimal `licenses.csv` subscription registry was accepted for V1 exploration. It is only licensing data, never business data. No GitHub credentials/tokens are embedded in the distributed app.
- Do not implement subscription UI or GitHub licence lookup in the billing/backup modules unless explicitly asked.

## Current source tree status

This source package contains an early permanent WPF application foundation, not a completed product. Existing files include:
- WPF startup and main shell.
- Shop profile setup/repository.
- SQLite initial schema and migration runner.
- Inventory repository and stock-entry service.
- Add Stock and Inventory screens.
- `StockSnapshotWriter` that writes `StockData.json` format `ORVA_STOCK_DATA`, `FormatVersion = 1`.
- English/Bengali resource dictionaries and local language preference.

Not yet implemented: complete billing/invoice issuance, payments UI, sales return workflow, complete shop backup/restore, stock import, full reports, printer integration, USB barcode integration, subscription module and production installer validation.

The project has **not been compiled/tested on Windows in this environment**. Do not claim a successful Windows build or hardware test unless you actually perform it on a suitable Windows machine.

## Engineering constraints

- Preserve C# 7.3 and .NET Framework 4.8.1 compatibility. Do not use records, nullable reference types, file-scoped namespaces, `using var`, top-level statements, or APIs unavailable to .NET Framework 4.8.1.
- Use the existing pinned `System.Data.SQLite.Core` 1.0.119 package unless a clear compatibility issue is demonstrated.
- Money is stored as integer paise (`long`/SQLite INTEGER); quantities are stored as thousandths (`quantity_milli`, SQLite INTEGER). Never use floating-point for money or stock arithmetic.
- Use parameterised SQL. Use transactions for multi-record business operations. Foreign keys are enabled. SQLite WAL and `synchronous=FULL` are configured in `SqliteDatabase`.
- Keep UI, domain/business logic and database infrastructure separated.
- Do not refactor unrelated files. Do not change migration 001 destructively. Add a new migration only when necessary and explain it.
- Do not hardcode medicine tax rates or silently assume a default 0% means exempt. Do not make legal conclusions. Any tax calculation inputs/modes must be explicit and configurable; flag unresolved CA validation clearly.
- No fake data, no fabricated test results, no broad rewrite. Return actual changed source files and a precise change report.

## Current AI development ownership (billing implementation)

- `Domain/Billing/BillingContracts.cs` is the frozen public boundary between billing backend and WPF billing UI.
- Gemini owns implementation of `IBillingService`, billing calculators, FEFO allocation, SQLite transaction handling, billing migrations and backend tests.
- Qwen owns the native WPF BillingView, view model, dynamic invoice cart and on-screen 58mm/80mm/A4/A5 preview consuming the frozen contract.
- ChatGPT owns AppServices/MainWindow integration, project/resource wiring, merge review, build fixes and final regression verification.
- The separate Qwen portability assignment (StockData import and ShopBackup restore) is deferred until billing backend/UI are integrated.
- Do not replace WPF with a web UI. Do not let either external model edit the other model's owned files or the frozen billing contract.