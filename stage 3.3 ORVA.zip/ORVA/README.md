# ORVA — Pharmacy Billing & Inventory (by Rindle Works)

**Version:** 1.0.0 (Stage 3.2 Complete Source)  
**Platform:** Windows 10 / 11 Desktop — Native WPF, C# 7.3, `.NET Framework 4.8` (`net48`), Local Unencrypted SQLite (`System.Data.SQLite.Core` 1.0.119)

> **Framework Compatibility Note (`net48` vs `.NET Framework 4.8.1`):**  
> The solution intentionally targets `net48` because .NET Framework 4.8 is pre-installed on Windows 10 21H2/22H2 and executes natively on both 4.8 and 4.8.1 runtimes without forcing a separate 4.8.1 runtime upgrade on older Windows 10 machines.

## Implemented Modules (Stages 1, 2, 3, 3.1 & 3.2)

- **Billing & GST Engine (Stage 1):** Automatic FEFO batch allocation, integer paise & thousandths math, explicit per-medicine `gst_rate_configured` enforcement, Mod-36 GSTIN validation, mandatory 2-digit Indian GST State Code, 16-char GST Rule 46 invoice numbering, split payments (Cash / UPI / Debit / Credit), busy-state draft lock, and `CartList`-scoped `Delete` shortcut.
- **Inventory, Portable Stock Transfer & Full Shop Backup (Stage 2):** Medicine/batch catalogue, 4-tier expiry alerts (`90d` `#1E3FA6`, `60d` `#FF7A57`, `30d` `#FF4B1F`, `Expired` `#D42A2A`), medicine-level low-stock alerts, stock adjustments, generation-safe `StockData.json` v2 with v1 import compatibility, and unencrypted `ShopBackup.shopbackup` with online SQLite backup, SHA-256 tamper detection, automatic daily backups, and rollback-safe restore.
- **Sales Returns, Cancellation, Records, Exports, Printing & Licensing (Stage 3 & 3.1):** Quarantine-by-default Sales Returns, safe Invoice Cancellation with atomic batch stock restoration, Invoice Archive with Reprint & Date Filters, Records & Tax (Purchases, Net-of-Returns GST/HSN Summary, Sales Returns, Stock Valuation, Expenses) with **CSV, Excel (`.xlsx`), and PDF** exports, bulk CSV/XLSX medicine catalogue import, native Windows printing (58mm/80mm natural-height thermal + multi-page A4/A5 pagination + saved printer restore), and offline-capable GitHub CSV Subscription & Support with scannable offline **UPI QR** rendering.
- **Editorial Pharmacy UI Motion & Print-Craft Identity (Stage 3.2):** Central OS reduced-motion gate (`UiMotion`), two-ink overprint stamp plate + `RegistrationMark` crosshairs on committed bills, procedural paper grain on sidebar/dialog headers, tactile button press feedback, barcode scan pulse, cart-row add flash, inline search empty-state, branded `OrvaConfirmDialog`, and 10 bundled SIL OFL Noto TTF fonts (256 matched EN/BN resource keys).

## Build, Test & Installer (Windows 10/11)

```powershell
powershell -ExecutionPolicy Bypass -File installer\BUILD_WINDOWS_RELEASE.ps1
```