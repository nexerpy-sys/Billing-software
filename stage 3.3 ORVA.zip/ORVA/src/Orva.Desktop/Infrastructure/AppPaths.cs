using System;
using System.IO;

namespace Orva.Infrastructure
{
    public static class AppPaths
    {
        public static string ProductRoot
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Rindle Works", "ORVA"); }
        }

        public static string DataDirectory { get { return Path.Combine(ProductRoot, "Data"); } }
        public static string DatabasePath { get { return Path.Combine(DataDirectory, "orva.sqlite"); } }
        public static string LogsDirectory { get { return Path.Combine(ProductRoot, "Logs"); } }
        public static string BackupsDirectory { get { return Path.Combine(ProductRoot, "Backups"); } }

        public static void EnsureDirectories()
        {
            Directory.CreateDirectory(ProductRoot);
            Directory.CreateDirectory(DataDirectory);
            Directory.CreateDirectory(LogsDirectory);
            Directory.CreateDirectory(BackupsDirectory);
        }

        public static string GetShopFolder(string shopName)
        {
            var documents = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            return Path.Combine(documents, MakeSafeFolderName(shopName));
        }

        public static string MakeSafeFolderName(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return "ORVA Shop Data";
            var invalid = Path.GetInvalidFileNameChars();
            var chars = value.Trim().ToCharArray();
            for (var i = 0; i < chars.Length; i++)
            {
                if (Array.IndexOf(invalid, chars[i]) >= 0) chars[i] = '-';
            }
            var result = new string(chars).Trim().TrimEnd('.');
            return string.IsNullOrWhiteSpace(result) ? "ORVA Shop Data" : result;
        }
    }
}