using System;
using System.Threading.Tasks;
using System.Windows;
using Orva.Infrastructure;
using Orva.Infrastructure.Database;
using Orva.Infrastructure.Repositories;
using Orva.Services;
using Orva.Services.Billing;
using Orva.Views;

namespace Orva
{
    public partial class App : Application
    {
        public static AppServices Services { get; private set; }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            try
            {
                AppPaths.EnsureDirectories();

                var database = new SqliteDatabase(AppPaths.DatabasePath);
                new DatabaseMigrator(database).Migrate();

                var shopRepository = new ShopRepository(database);
                var inventoryRepository = new InventoryRepository(database);
                var taxSettingsRepository = new TaxSettingsRepository(database);
                var snapshotWriter = new StockSnapshotWriter(database, shopRepository);
                var stockEntryService = new StockEntryService(inventoryRepository, snapshotWriter);
                var stockAdjustmentService = new StockAdjustmentService(inventoryRepository, snapshotWriter);
                var appSettings = new AppSettingsRepository(database);
                var shopBackupService = new ShopBackupService(database, shopRepository, snapshotWriter);
                var automaticBackupCoordinator = new AutomaticBackupCoordinator(shopBackupService, appSettings);
                var stockDataImporter = new StockDataImporter(
                    database,
                    shopRepository,
                    snapshotWriter,
                    reason => shopBackupService.CreateSafetyBackup(reason));
                var medicineCatalogueImporter = new MedicineCatalogueImporter(database, snapshotWriter);
                var salesReturnService = new SalesReturnService(database, snapshotWriter);
                var invoiceCancellationService = new InvoiceCancellationService(database, snapshotWriter);
                var reportingService = new ReportingService(database);
                var invoicePrintService = new InvoicePrintService(appSettings);
                var subscriptionService = new SubscriptionService(appSettings);
                var billingService = new BillingService(database, snapshotWriter);

                Services = new AppServices(
                    database,
                    shopRepository,
                    inventoryRepository,
                    taxSettingsRepository,
                    stockEntryService,
                    stockAdjustmentService,
                    snapshotWriter,
                    stockDataImporter,
                    medicineCatalogueImporter,
                    shopBackupService,
                    automaticBackupCoordinator,
                    salesReturnService,
                    invoiceCancellationService,
                    reportingService,
                    invoicePrintService,
                    subscriptionService,
                    appSettings,
                    billingService);

                LocalizationManager.SetLanguage(appSettings.Get("display_language", "en"));

                bool firstRunCompleted = false;
                if (shopRepository.GetProfile() == null)
                {
                    var setup = new ShopSetupWindow(shopRepository);
                    if (setup.ShowDialog() != true)
                    {
                        Shutdown();
                        return;
                    }
                    firstRunCompleted = true;
                }

                try
                {
                    Services.SnapshotWriter.WriteCurrentSnapshot();
                }
                catch
                {
                    // A snapshot failure must not prevent normal offline billing.
                }

                // Trigger initial/daily backup and optional subscription check asynchronously without blocking startup UI.
                Task.Run(async delegate
                {
                    try
                    {
                        if (firstRunCompleted)
                            Services.AutomaticBackupCoordinator.RunBackupNow();
                        else
                            Services.AutomaticBackupCoordinator.RunDailyBackupIfDue();
                    }
                    catch { }

                    try
                    {
                        var sub = Services.SubscriptionService.EvaluateLocalStatus();
                        if (sub.IsConfigured && (!sub.LastVerifiedUtc.HasValue || (DateTime.UtcNow - sub.LastVerifiedUtc.Value).TotalHours >= SubscriptionService.RefreshIntervalHours))
                        {
                            await Services.SubscriptionService.RefreshFromRegistryAsync();
                        }
                    }
                    catch { }
                });

                var main = new MainWindow();
                MainWindow = main;
                main.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "ORVA could not start because its local data could not be opened.\n\n" + ex.Message +
                    "\n\nYour existing business data has not been intentionally deleted. Please contact support if this continues.",
                    "ORVA — Startup problem",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                Shutdown(-1);
            }
        }
    }
}