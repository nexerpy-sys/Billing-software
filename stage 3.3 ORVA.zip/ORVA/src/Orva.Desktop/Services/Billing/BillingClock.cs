using System;

namespace Orva.Services.Billing
{
    public interface IBillingClock
    {
        DateTime UtcNow { get; }
        int LocalOffsetMinutes { get; }
        DateTime LocalNow { get; }
        int CurrentExpiryYearMonth { get; }
    }

    public sealed class SystemBillingClock : IBillingClock
    {
        public DateTime UtcNow
        {
            get { return DateTime.UtcNow; }
        }

        public int LocalOffsetMinutes
        {
            get
            {
                var offset = TimeZoneInfo.Local.GetUtcOffset(DateTime.UtcNow);
                return (int)offset.TotalMinutes;
            }
        }

        public DateTime LocalNow
        {
            get { return DateTime.Now; }
        }

        public int CurrentExpiryYearMonth
        {
            get
            {
                var local = DateTime.Now;
                return local.Year * 100 + local.Month;
            }
        }
    }
}