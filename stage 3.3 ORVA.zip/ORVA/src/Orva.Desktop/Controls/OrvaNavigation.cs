using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using Orva.Services;

namespace Orva.Controls
{
    /// <summary>
    /// Animated content navigation. The new view is assigned IMMEDIATELY (no async
    /// swap, so rapid clicks can never lose the final destination), then revealed
    /// with a short fade + rise. Repeated calls replace, never stack, the motion.
    /// </summary>
    public static class OrvaNavigation
    {
        private static readonly DependencyProperty NavStoryboardProperty =
            DependencyProperty.RegisterAttached(
                "NavStoryboard", typeof(Storyboard), typeof(OrvaNavigation),
                new PropertyMetadata(null));

        public static void SetContent(ContentControl host, object content)
        {
            if (host == null) return;

            var previous = (Storyboard)host.GetValue(NavStoryboardProperty);
            UiMotion.Stop(host, previous);

            host.Content = content;

            if (!UiMotion.Enabled)
            {
                host.Opacity = 1.0;
                return;
            }

            bool hasTransforms = UiMotion.EnsureTransforms(host);
            host.Opacity = 0.0;

            var sb = new Storyboard();
            UiMotion.Add(sb, host, "Opacity", UiMotion.Anim(0.0, 1.0, UiMotion.Normal, UiMotion.EaseOut()));
            if (hasTransforms)
            {
                UiMotion.Add(sb, host, UiMotion.TranslateYPath, UiMotion.Anim(12.0, 0.0, UiMotion.Normal, UiMotion.EaseOut()));
            }

            host.SetValue(NavStoryboardProperty, sb);
            UiMotion.Run(host, sb);
        }
    }
}
