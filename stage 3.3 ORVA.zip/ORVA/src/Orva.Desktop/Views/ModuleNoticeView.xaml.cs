using System.Windows.Controls;

namespace Orva.Views
{
    public partial class ModuleNoticeView : UserControl
    {
        public ModuleNoticeView(string message)
        {
            InitializeComponent();
            NoticeText.Text = message;
        }
    }
}