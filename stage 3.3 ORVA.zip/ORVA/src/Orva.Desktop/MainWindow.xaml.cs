using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using Orva.Controls;
using Orva.Services;
using Orva.ViewModels;
using Orva.Views;

namespace Orva
{
    public partial class MainWindow : Window
    {
        private readonly DispatcherTimer _dailyBackupTimer;

        public MainWindow()
        {
            InitializeComponent();

            RefreshShopHeader();
            ApplyLanguageSelection();
            ShowBilling();
            Loaded += MainWindow_Loaded;

            _dailyBackupTimer = new DispatcherTimer { Interval = TimeSpan.FromHours(1) };
            _dailyBackupTimer.Tick += DailyBackupTimer_Tick;
            _dailyBackupTimer.Start();
            Closed += MainWindow_Closed;
        }

        private void RefreshShopHeader()
        {
            var profile = App.Services.ShopRepository.GetProfile();
            ShopNameText.Text = profile == null ? "Medical store" : profile.ShopName;
            CurrentDateText.Text = DateTime.Now.ToString("dd MMM yyyy").ToUpperInvariant();
        }

        private void DailyBackupTimer_Tick(object sender, EventArgs e)
        {
            Task.Run(delegate
            {
                try
                {
                    App.Services.AutomaticBackupCoordinator.RunDailyBackupIfDue();
                }
                catch { }
            });
        }

        private void MainWindow_Closed(object sender, EventArgs e)
        {
            _dailyBackupTimer.Stop();
        }

        private void ApplyLanguageSelection()
        {
            EnglishButton.Background = LocalizationManager.CurrentLanguage == "en"
                ? (System.Windows.Media.Brush)FindResource("Paper")
                : System.Windows.Media.Brushes.Transparent;

            BengaliButton.Background = LocalizationManager.CurrentLanguage == "bn"
                ? (System.Windows.Media.Brush)FindResource("Paper")
                : System.Windows.Media.Brushes.Transparent;
        }

        private void SetPage(string title, string eyebrow, FrameworkElement page)
        {
            PageTitle.Text = title;
            PageEyebrow.Text = eyebrow;
            PageHost.Content = page;
        }

        private void ShowBilling()
        {
            RefreshShopHeader();

            // Enforce subscription billing-only restriction if configured and grace period has expired.
            // Historical invoices, records, exports, and backups remain fully accessible.
            var subStatus = App.Services.SubscriptionService.EvaluateLocalStatus();
            if (!subStatus.AllowNewBilling)
            {
                SetPage(
                    LocalizationManager.Get("PageBillingTitle"),
                    LocalizationManager.Get("PageBillingEyebrow"),
                    new ModuleNoticeView(subStatus.Message));
                return;
            }

            var profile = App.Services.ShopRepository.GetProfile();
            var header = BillingShopHeader.FromProfile(profile);
            var billingView = new BillingView(App.Services.BillingService, header);
            billingView.ViewModel.SelectedPaperFormat = App.Services.InvoicePrintService.GetDefaultPaperFormat();
            billingView.ViewModel.PrintRequested += (s, args) =>
            {
                var printResult = App.Services.InvoicePrintService.PrintInvoice(
                    args.Invoice,
                    args.Preview,
                    args.PaperFormat,
                    billingView.ViewModel.ShopHeader,
                    billingView.ViewModel.CustomerName,
                    billingView.ViewModel.CustomerPhone,
                    billingView.ViewModel.CustomerAddress,
                    billingView.ViewModel.CustomerGstin,
                    billingView.ViewModel.Tenders);

                if (!printResult.Printed && !printResult.CancelledByUser && !string.IsNullOrWhiteSpace(printResult.ErrorMessage))
                {
                    MessageBox.Show(this, printResult.ErrorMessage, "ORVA — Printing", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            };

            SetPage(
                LocalizationManager.Get("PageBillingTitle"),
                LocalizationManager.Get("PageBillingEyebrow"),
                billingView);
        }

        private void ShowInventory()
        {
            SetPage(
                LocalizationManager.Get("PageInventoryTitle"),
                LocalizationManager.Get("PageInventoryEyebrow"),
                new InventoryView());
        }

        private void ShowInvoices()
        {
            SetPage(
                LocalizationManager.Get("PageInvoicesTitle"),
                LocalizationManager.Get("PageInvoicesEyebrow"),
                new InvoicesView());
        }

        private void ShowReturns()
        {
            SetPage(
                LocalizationManager.Get("PageReturnsTitle"),
                LocalizationManager.Get("PageReturnsEyebrow"),
                new SalesReturnsView());
        }

        private void ShowRecords()
        {
            SetPage(
                LocalizationManager.Get("PageRecordsTitle"),
                LocalizationManager.Get("PageRecordsEyebrow"),
                new RecordsView());
        }

        private void ShowSettings()
        {
            var settingsView = new SettingsView(App.Services.ShopRepository, App.Services.TaxSettingsRepository);
            settingsView.DatabaseRestored += SettingsView_DatabaseRestored;

            SetPage(
                LocalizationManager.Get("PageSettingsTitle"),
                LocalizationManager.Get("PageSettingsEyebrow"),
                settingsView);
        }

        private void ShowSubscription()
        {
            SetPage(
                LocalizationManager.Get("PageSubscriptionTitle"),
                LocalizationManager.Get("PageSubscriptionEyebrow"),
                new SubscriptionView());
        }

        private void SettingsView_DatabaseRestored(object sender, EventArgs e)
        {
            LocalizationManager.SetLanguage(App.Services.AppSettings.Get("display_language", "en"));
            ApplyLanguageSelection();
            ShowBilling();
        }

        private void Inventory_Click(object sender, RoutedEventArgs e) { ShowInventory(); }
        private void Billing_Click(object sender, RoutedEventArgs e) { ShowBilling(); }
        private void Invoices_Click(object sender, RoutedEventArgs e) { ShowInvoices(); }
        private void Returns_Click(object sender, RoutedEventArgs e) { ShowReturns(); }
        private void Records_Click(object sender, RoutedEventArgs e) { ShowRecords(); }
        private void Settings_Click(object sender, RoutedEventArgs e) { ShowSettings(); }
        private void Subscription_Click(object sender, RoutedEventArgs e) { ShowSubscription(); }

        private void English_Click(object sender, RoutedEventArgs e)
        {
            LocalizationManager.SetLanguage("en");
            App.Services.AppSettings.Set("display_language", "en");
            ApplyLanguageSelection();
            ShowBilling();
        }

        private void Bengali_Click(object sender, RoutedEventArgs e)
        {
            LocalizationManager.SetLanguage("bn");
            App.Services.AppSettings.Set("display_language", "bn");
            ApplyLanguageSelection();
            ShowBilling();
        }
    }
}