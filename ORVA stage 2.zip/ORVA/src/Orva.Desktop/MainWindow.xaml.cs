using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using Orva.Services;
using Orva.ViewModels;
using Orva.Views;

namespace Orva
{
    public partial class MainWindow : Window
    {
        private readonly DispatcherTimer _dailyBackupTimer;

        public MainWindow()
        {
            InitializeComponent();

            RefreshShopHeader();
            ApplyLanguageSelection();
            ShowBilling();

            _dailyBackupTimer = new DispatcherTimer { Interval = TimeSpan.FromHours(1) };
            _dailyBackupTimer.Tick += DailyBackupTimer_Tick;
            _dailyBackupTimer.Start();
            Closed += MainWindow_Closed;
        }

        private void RefreshShopHeader()
        {
            var profile = App.Services.ShopRepository.GetProfile();
            ShopNameText.Text = profile == null ? "Medical store" : profile.ShopName;
            CurrentDateText.Text = DateTime.Now.ToString("dd MMM yyyy").ToUpperInvariant();
        }

        private void DailyBackupTimer_Tick(object sender, EventArgs e)
        {
            Task.Run(delegate
            {
                try
                {
                    App.Services.AutomaticBackupCoordinator.RunDailyBackupIfDue();
                }
                catch
                {
                    // Non-fatal background backup check
                }
            });
        }

        private void MainWindow_Closed(object sender, EventArgs e)
        {
            _dailyBackupTimer.Stop();
        }

        private void ApplyLanguageSelection()
        {
            EnglishButton.Background = LocalizationManager.CurrentLanguage == "en"
                ? (System.Windows.Media.Brush)FindResource("Paper")
                : System.Windows.Media.Brushes.Transparent;

            BengaliButton.Background = LocalizationManager.CurrentLanguage == "bn"
                ? (System.Windows.Media.Brush)FindResource("Paper")
                : System.Windows.Media.Brushes.Transparent;
        }

        private void SetPage(string title, string eyebrow, FrameworkElement page)
        {
            PageTitle.Text = title;
            PageEyebrow.Text = eyebrow;
            PageHost.Content = page;
        }

        private void ShowBilling()
        {
            RefreshShopHeader();
            var profile = App.Services.ShopRepository.GetProfile();
            var header = BillingShopHeader.FromProfile(profile);

            SetPage(
                LocalizationManager.Get("PageBillingTitle"),
                LocalizationManager.Get("PageBillingEyebrow"),
                new BillingView(App.Services.BillingService, header));
        }

        private void ShowInventory()
        {
            SetPage(
                LocalizationManager.Get("PageInventoryTitle"),
                LocalizationManager.Get("PageInventoryEyebrow"),
                new InventoryView());
        }

        private void ShowSettings()
        {
            var settingsView = new SettingsView(App.Services.ShopRepository, App.Services.TaxSettingsRepository);
            settingsView.DatabaseRestored += SettingsView_DatabaseRestored;

            SetPage(
                LocalizationManager.Get("PageSettingsTitle"),
                LocalizationManager.Get("PageSettingsEyebrow"),
                settingsView);
        }

        private void SettingsView_DatabaseRestored(object sender, EventArgs e)
        {
            // Re-read persisted language and shop profile from the newly restored database and open fresh BillingView.
            LocalizationManager.SetLanguage(App.Services.AppSettings.Get("display_language", "en"));
            ApplyLanguageSelection();
            ShowBilling();
        }

        private void Inventory_Click(object sender, RoutedEventArgs e) { ShowInventory(); }
        private void Billing_Click(object sender, RoutedEventArgs e) { ShowBilling(); }

        private void Invoices_Click(object sender, RoutedEventArgs e)
        {
            SetPage("Invoices", "ORVA  /  SALES RECORDS",
                new ModuleNoticeView("The invoice archive will be connected to the permanent billing records."));
        }

        private void Returns_Click(object sender, RoutedEventArgs e)
        {
            SetPage("Sales Returns", "ORVA  /  RETURNS",
                new ModuleNoticeView("Returns will be linked to original invoices. Returned stock will remain quarantined until assessed."));
        }

        private void Records_Click(object sender, RoutedEventArgs e)
        {
            SetPage("Records & Tax", "ORVA  /  BUSINESS RECORDS",
                new ModuleNoticeView("Sales, purchase, GST and export registers will be connected to permanent transaction records."));
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            ShowSettings();
        }

        private void Subscription_Click(object sender, RoutedEventArgs e)
        {
            SetPage("Subscription & Support", "ORVA  /  LICENCE",
                new ModuleNoticeView("Subscription plans, UPI payment and support remain separate from billing."));
        }

        private void English_Click(object sender, RoutedEventArgs e)
        {
            LocalizationManager.SetLanguage("en");
            App.Services.AppSettings.Set("display_language", "en");
            ApplyLanguageSelection();
            ShowBilling();
        }

        private void Bengali_Click(object sender, RoutedEventArgs e)
        {
            LocalizationManager.SetLanguage("bn");
            App.Services.AppSettings.Set("display_language", "bn");
            ApplyLanguageSelection();
            ShowBilling();
        }
    }
}