# ORVA — ChatGPT Integration Ownership

ChatGPT is the architecture/integration owner, not a competing implementation branch.

## Responsibilities retained by ChatGPT

1. Maintain product requirements and the single authoritative `AI_COLLABORATION_CONTEXT.md`.
2. Freeze and maintain the public backend/UI contract in `BillingContracts.cs` and its documentation.
3. Keep Gemini and Qwen file ownership disjoint.
4. Review their ZIPs against the real current source tree and reject broad or unrelated rewrites.
5. Integrate `BillingService` from Gemini into `AppServices` and connect Qwen's `BillingView` to `MainWindow`.
6. Resolve project-file, resource and namespace registration after both branches return.
7. Integrate portable stock import and full backup/restore after billing/UI contract is stable.
8. Integrate invoice printing, barcode scanner input, subscription registry and activation workflow in separate controlled tasks.
9. Run static/schema checks available in the current environment; arrange Windows build/test verification and report limitations honestly.
10. Preserve the core requirement: ORVA must suit the real owner and staff described. Every interaction must minimise typing, decisions, technical concepts and customer waiting.

## File ownership

| Area | Owner |
|---|---|
| Billing DTO/interface contract | ChatGPT (frozen boundary) |
| Billing service, calculator, FEFO, persistence, tests | Gemini |
| New Billing WPF view, view-model, live paper preview | Qwen |
| `AppServices.cs`, `MainWindow.xaml`, `MainWindow.xaml.cs` integration | ChatGPT |
| Database migrations integration | ChatGPT after Gemini review |
| Printer integration | Later ChatGPT-controlled task |
| Backup/restore and stock import | Deferred separate Qwen task after billing merge |
| Subscription/GitHub licensing | Deferred separate task |

## Merge protocol

- Both models receive the same source ZIP and exact `BillingContracts.cs`.
- They must not modify each other's owned files.
- Each returns changed files only, preserving paths under `ORVA/`, plus an implementation report.
- ChatGPT compares each changed file against the baseline and contract before merging.
- Never accept a claim of successful Windows compilation unless the model supplies actual build/test evidence.

