# ORVA AI Development Assignments v2

## Agreed division of work

- **Gemini 4 Argon:** Billing backend, ledger/money/tax arithmetic, FEFO allocation, transactional SQLite persistence, invoice sequencing and difficult edge-case tests.
- **Qwen 4 Max:** Native WPF billing workspace, interactive cart/dynamic table, customer/payment interface and live on-screen invoice preview for 58mm, 80mm, A4 and A5.
- **ChatGPT:** Shared contracts, routing/integration, AppServices and MainWindow wiring, review, project registration, merge conflict resolution and final verification.

Qwen's general strength in web UI is adapted to ORVA's real platform: WPF desktop XAML and C#, not React/HTML/web code. Its “live preview” assignment is the on-screen WPF invoice paper preview.

## Files to give each model

Give **the same source ZIP** to both models:
`ORVA_Source_Package_Billing_v2.zip`

Then give Gemini:
`ORVA_GEMINI_TASK_PROMPT_v2.txt`

Give Qwen:
`ORVA_QWEN_TASK_PROMPT_v2.txt`

The source ZIP includes the frozen contract:
- `ORVA/src/Orva.Desktop/Domain/Billing/BillingContracts.cs`
- `ORVA/docs/BILLING_UI_BACKEND_CONTRACT_v1.md`

## Strict ownership boundary

Gemini must not edit WPF views, MainWindow or AppServices. Qwen must not edit the schema, repositories, billing backend or AppServices/MainWindow. Neither may modify `BillingContracts.cs`. ChatGPT will integrate both outputs.

## Deferred work

Qwen's earlier portable backup/restore assignment is deferred. It should not be run concurrently with the billing UI task. We will assign it after the billing backend and UI merge, using the updated database schema.

## Important

The source is an early permanent WPF foundation. Do not claim a Windows build, test, live preview or hardware validation unless it was actually performed. The actual owner/staff usability constraint is mandatory for every contribution.