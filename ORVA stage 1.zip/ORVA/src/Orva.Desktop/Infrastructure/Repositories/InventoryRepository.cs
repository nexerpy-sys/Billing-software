using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Globalization;
using Orva.Domain;
using Orva.Infrastructure.Database;
using Orva.Services;

namespace Orva.Infrastructure.Repositories
{
    public sealed class InventoryRepository
    {
        private readonly SqliteDatabase _database;
        public InventoryRepository(SqliteDatabase database) { _database = database; }

        public string SaveStockEntry(StockEntryInput input)
        {
            Validate(input);
            var nowUtc = DateTime.UtcNow;
            var now = nowUtc.ToString("o", CultureInfo.InvariantCulture);
            var medicineId = Guid.NewGuid().ToString("N");
            var batchId = Guid.NewGuid().ToString("N");
            var purchaseId = Guid.NewGuid().ToString("N");
            var movementId = Guid.NewGuid().ToString("N");
            var auditId = Guid.NewGuid().ToString("N");
            var normalizedName = NormalizeName(input.MedicineName);

            using (var connection = _database.OpenConnection())
            using (var transaction = connection.BeginTransaction())
            {
                medicineId = FindOrCreateMedicine(connection, transaction, input, normalizedName, now);
                batchId = FindOrCreateBatch(connection, transaction, medicineId, input, now);

                using (var purchase = new SQLiteCommand(@"
INSERT INTO purchase_receipt(purchase_id, received_at_utc, supplier_name_text, supplier_licence_text, document_type, document_reference, subtotal_paise, total_tax_paise, total_paise, created_at_utc)
VALUES(@id, @received, @supplier, @supplier_licence, @document_type, @document_reference, @subtotal, 0, @total, @created);", connection, transaction))
                {
                    purchase.Parameters.AddWithValue("@id", purchaseId);
                    purchase.Parameters.AddWithValue("@received", now);
                    purchase.Parameters.AddWithValue("@supplier", Db(input.SupplierName));
                    purchase.Parameters.AddWithValue("@supplier_licence", Db(input.SupplierLicence));
                    purchase.Parameters.AddWithValue("@document_type", input.DocumentType);
                    purchase.Parameters.AddWithValue("@document_reference", Db(input.DocumentReference));
                    purchase.Parameters.AddWithValue("@subtotal", MultiplyMoney(input.QuantityMilli, input.PurchasePricePaise));
                    purchase.Parameters.AddWithValue("@total", MultiplyMoney(input.QuantityMilli, input.PurchasePricePaise));
                    purchase.Parameters.AddWithValue("@created", now);
                    purchase.ExecuteNonQuery();
                }

                using (var line = new SQLiteCommand(@"
INSERT INTO purchase_line(purchase_line_id, purchase_id, batch_id, medicine_id, quantity_milli, unit_name_snapshot, unit_purchase_price_paise, line_total_paise, created_at_utc)
VALUES(@id, @purchase, @batch, @medicine, @quantity, @unit, @price, @total, @created);", connection, transaction))
                {
                    line.Parameters.AddWithValue("@id", Guid.NewGuid().ToString("N"));
                    line.Parameters.AddWithValue("@purchase", purchaseId);
                    line.Parameters.AddWithValue("@batch", batchId);
                    line.Parameters.AddWithValue("@medicine", medicineId);
                    line.Parameters.AddWithValue("@quantity", input.QuantityMilli);
                    line.Parameters.AddWithValue("@unit", input.StockUnitName.Trim());
                    line.Parameters.AddWithValue("@price", input.PurchasePricePaise);
                    line.Parameters.AddWithValue("@total", MultiplyMoney(input.QuantityMilli, input.PurchasePricePaise));
                    line.Parameters.AddWithValue("@created", now);
                    line.ExecuteNonQuery();
                }

                using (var movement = new SQLiteCommand(@"
INSERT INTO stock_movement(movement_id, batch_id, medicine_id, movement_type, quantity_delta_milli, reference_type, reference_id, reason, created_at_utc, created_local_text)
VALUES(@id, @batch, @medicine, 'PURCHASE', @quantity, 'PURCHASE_RECEIPT', @reference, 'Stock received', @utc, @local);", connection, transaction))
                {
                    movement.Parameters.AddWithValue("@id", movementId);
                    movement.Parameters.AddWithValue("@batch", batchId);
                    movement.Parameters.AddWithValue("@medicine", medicineId);
                    movement.Parameters.AddWithValue("@quantity", input.QuantityMilli);
                    movement.Parameters.AddWithValue("@reference", purchaseId);
                    movement.Parameters.AddWithValue("@utc", now);
                    movement.Parameters.AddWithValue("@local", nowUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
                    movement.ExecuteNonQuery();
                }

                using (var audit = new SQLiteCommand(@"
INSERT INTO audit_log(audit_id, action_type, entity_type, entity_id, summary, before_json, after_json, created_at_utc, created_local_text)
VALUES(@id, 'STOCK_RECEIVED', 'STOCK_BATCH', @entity, @summary, NULL, @after, @utc, @local);", connection, transaction))
                {
                    audit.Parameters.AddWithValue("@id", auditId);
                    audit.Parameters.AddWithValue("@entity", batchId);
                    audit.Parameters.AddWithValue("@summary", "Received " + FormatQuantity(input.QuantityMilli) + " " + input.StockUnitName + " of " + input.MedicineName.Trim());
                    audit.Parameters.AddWithValue("@after", "{\"purchaseId\":\"" + purchaseId + "\",\"movementId\":\"" + movementId + "\"}");
                    audit.Parameters.AddWithValue("@utc", now);
                    audit.Parameters.AddWithValue("@local", nowUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
                    audit.ExecuteNonQuery();
                }

                // Increment the snapshot generation and mark dirty inside the same transaction as the stock receipt.
                // If the process exits immediately after commit or a concurrent snapshot writer finishes, the generation guard preserves dirty=1.
                StockSnapshotState.MarkDirtyAndIncrementGeneration(connection, transaction, now);

                transaction.Commit();
            }
            return batchId;
        }

        public IList<InventoryRow> GetInventoryRows(string searchText)
        {
            var rows = new List<InventoryRow>();
            var sql = @"
SELECT m.medicine_id, b.batch_id, m.display_name, b.batch_number, b.expiry_yyyymm,
       b.quantity_milli, b.stock_unit_name, b.mrp_paise, b.batch_status,
       m.low_stock_threshold_milli,
       COALESCE((SELECT SUM(b2.quantity_milli) FROM stock_batch b2
                 WHERE b2.medicine_id=m.medicine_id AND b2.batch_status='ACTIVE'
                   AND b2.expiry_yyyymm >= @current_month), 0) AS usable_total
FROM stock_batch b
JOIN medicine m ON m.medicine_id = b.medicine_id
WHERE m.is_active = 1
  AND (@search = '' OR m.normalized_name LIKE @like OR UPPER(b.batch_number) LIKE @like)
ORDER BY m.display_name COLLATE NOCASE, b.expiry_yyyymm, b.batch_number;";
            using (var connection = _database.OpenConnection())
            using (var command = new SQLiteCommand(sql, connection))
            {
                var search = (searchText ?? string.Empty).Trim().ToUpperInvariant();
                command.Parameters.AddWithValue("@search", search);
                command.Parameters.AddWithValue("@like", "%" + search + "%");
                command.Parameters.AddWithValue("@current_month", DateTime.Now.Year * 100 + DateTime.Now.Month);
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var expiry = reader.GetInt32(4);
                        var quantity = reader.GetInt64(5);
                        var status = GetDisplayStatus(reader.GetString(8), expiry, quantity, reader.GetInt64(9), reader.GetInt64(10));
                        rows.Add(new InventoryRow
                        {
                            MedicineId = reader.GetString(0),
                            BatchId = reader.GetString(1),
                            MedicineName = reader.GetString(2),
                            BatchNumber = reader.GetString(3),
                            Expiry = expiry.ToString("0000-00", CultureInfo.InvariantCulture),
                            Quantity = FormatQuantity(quantity),
                            Unit = reader.GetString(6),
                            Mrp = FormatMoney(reader.GetInt64(7)),
                            Status = status,
                            StatusColour = status == "Expired" ? "#C9362B" : (status == "Low stock" ? "#B56A13" : "#16845B")
                        });
                    }
                }
            }
            return rows;
        }

        public string GetStockUnitForMedicine(string medicineName)
        {
            if (string.IsNullOrWhiteSpace(medicineName)) return null;
            var normalized = NormalizeName(medicineName);
            using (var connection = _database.OpenConnection())
            using (var command = new SQLiteCommand("SELECT stock_unit_name FROM medicine WHERE normalized_name=@name AND is_active=1;", connection))
            {
                command.Parameters.AddWithValue("@name", normalized);
                return command.ExecuteScalar() as string;
            }
        }

        public int GetMedicineCount()
        {
            using (var connection = _database.OpenConnection())
            using (var command = new SQLiteCommand("SELECT COUNT(*) FROM medicine WHERE is_active = 1;", connection))
                return Convert.ToInt32(command.ExecuteScalar());
        }

        public int GetBatchCount()
        {
            using (var connection = _database.OpenConnection())
            using (var command = new SQLiteCommand("SELECT COUNT(*) FROM stock_batch;", connection))
                return Convert.ToInt32(command.ExecuteScalar());
        }

        private static string FindOrCreateMedicine(SQLiteConnection connection, SQLiteTransaction transaction, StockEntryInput input, string normalizedName, string now)
        {
            using (var find = new SQLiteCommand("SELECT medicine_id, stock_unit_name FROM medicine WHERE normalized_name = @name;", connection, transaction))
            {
                find.Parameters.AddWithValue("@name", normalizedName);
                using (var reader = find.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var existingId = reader.GetString(0);
                        var existingUnit = reader.GetString(1);
                        if (!string.Equals(existingUnit, input.StockUnitName.Trim(), StringComparison.OrdinalIgnoreCase))
                            throw new InvalidOperationException("This medicine is already recorded using the unit '" + existingUnit + "'. Use that unit for this stock entry.");
                        return existingId;
                    }
                }
            }

            var id = Guid.NewGuid().ToString("N");
            using (var insert = new SQLiteCommand(@"
INSERT INTO medicine(medicine_id, display_name, normalized_name, stock_unit_name, created_at_utc, updated_at_utc)
VALUES(@id, @name, @normalized, @unit, @created, @updated);", connection, transaction))
            {
                insert.Parameters.AddWithValue("@id", id);
                insert.Parameters.AddWithValue("@name", input.MedicineName.Trim());
                insert.Parameters.AddWithValue("@normalized", normalizedName);
                insert.Parameters.AddWithValue("@unit", input.StockUnitName.Trim());
                insert.Parameters.AddWithValue("@created", now);
                insert.Parameters.AddWithValue("@updated", now);
                insert.ExecuteNonQuery();
            }
            return id;
        }

        private static string FindOrCreateBatch(SQLiteConnection connection, SQLiteTransaction transaction, string medicineId, StockEntryInput input, string now)
        {
            string id = null;
            using (var find = new SQLiteCommand(@"SELECT batch_id, batch_status FROM stock_batch WHERE medicine_id=@medicine AND UPPER(TRIM(batch_number))=UPPER(TRIM(@batch)) AND expiry_yyyymm=@expiry;", connection, transaction))
            {
                find.Parameters.AddWithValue("@medicine", medicineId);
                find.Parameters.AddWithValue("@batch", input.BatchNumber.Trim());
                find.Parameters.AddWithValue("@expiry", input.ExpiryYearMonth);
                using (var reader = find.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        id = reader.GetString(0);
                        var status = reader.GetString(1);
                        if (!string.Equals(status, "ACTIVE", StringComparison.OrdinalIgnoreCase))
                            throw new InvalidOperationException("This batch is marked as " + status.ToLowerInvariant() + ". It must be checked before more stock is added.");
                    }
                }
            }

            if (id == null)
            {
                id = Guid.NewGuid().ToString("N");
                using (var insert = new SQLiteCommand(@"
INSERT INTO stock_batch(batch_id, medicine_id, batch_number, expiry_yyyymm, stock_unit_name, mrp_paise, latest_purchase_price_paise, quantity_milli, batch_status, created_at_utc, updated_at_utc)
VALUES(@id, @medicine, @batch, @expiry, @unit, @mrp, @purchase, @quantity, 'ACTIVE', @created, @updated);", connection, transaction))
                {
                    insert.Parameters.AddWithValue("@id", id);
                    insert.Parameters.AddWithValue("@medicine", medicineId);
                    insert.Parameters.AddWithValue("@batch", input.BatchNumber.Trim());
                    insert.Parameters.AddWithValue("@expiry", input.ExpiryYearMonth);
                    insert.Parameters.AddWithValue("@unit", input.StockUnitName.Trim());
                    insert.Parameters.AddWithValue("@mrp", input.MrpPaise);
                    insert.Parameters.AddWithValue("@purchase", input.PurchasePricePaise);
                    insert.Parameters.AddWithValue("@quantity", input.QuantityMilli);
                    insert.Parameters.AddWithValue("@created", now);
                    insert.Parameters.AddWithValue("@updated", now);
                    insert.ExecuteNonQuery();
                }
            }
            else
            {
                using (var update = new SQLiteCommand(@"
UPDATE stock_batch SET quantity_milli = quantity_milli + @quantity,
mrp_paise=@mrp, latest_purchase_price_paise=@purchase, updated_at_utc=@updated
WHERE batch_id=@id;", connection, transaction))
                {
                    update.Parameters.AddWithValue("@quantity", input.QuantityMilli);
                    update.Parameters.AddWithValue("@mrp", input.MrpPaise);
                    update.Parameters.AddWithValue("@purchase", input.PurchasePricePaise);
                    update.Parameters.AddWithValue("@updated", now);
                    update.Parameters.AddWithValue("@id", id);
                    update.ExecuteNonQuery();
                }
            }
            return id;
        }

        private static void Validate(StockEntryInput input)
        {
            if (input == null) throw new ArgumentNullException("input");
            if (string.IsNullOrWhiteSpace(input.MedicineName)) throw new ArgumentException("Enter the medicine name.");
            if (input.MedicineName.Trim().Length > 180) throw new ArgumentException("Medicine name is too long.");
            if (string.IsNullOrWhiteSpace(input.StockUnitName)) throw new ArgumentException("Choose the stock unit.");
            if (string.IsNullOrWhiteSpace(input.BatchNumber)) throw new ArgumentException("Enter the batch number.");
            if (input.BatchNumber.Trim().Length > 80) throw new ArgumentException("Batch number is too long.");
            if (input.ExpiryYearMonth < 200001 || input.ExpiryYearMonth > 219912) throw new ArgumentException("Choose a valid expiry month.");
            var currentMonth = DateTime.Now.Year * 100 + DateTime.Now.Month;
            if (input.ExpiryYearMonth < currentMonth) throw new ArgumentException("This batch has already passed its expiry month. Check the date before receiving it.");
            if (input.QuantityMilli <= 0) throw new ArgumentException("Enter a quantity greater than zero.");
            if (input.PurchasePricePaise < 0 || input.MrpPaise < 0) throw new ArgumentException("Prices cannot be negative.");
            if (string.IsNullOrWhiteSpace(input.DocumentType)) input.DocumentType = "NO_DOCUMENT";
            var allowed = new[] { "TAX_INVOICE", "CASH_CREDIT_MEMO", "NO_DOCUMENT", "OTHER" };
            if (Array.IndexOf(allowed, input.DocumentType) < 0) throw new ArgumentException("Choose a valid purchase document type.");
        }

        private static string GetDisplayStatus(string batchStatus, int expiryYyyyMm, long quantityMilli, long thresholdMilli, long usableTotalMilli)
        {
            var now = DateTime.Now;
            var expiryDate = new DateTime(expiryYyyyMm / 100, expiryYyyyMm % 100, 1).AddMonths(1).AddDays(-1);
            if (batchStatus == "QUARANTINED") return "Quarantined";
            if (batchStatus == "BLOCKED") return "Blocked";
            if (expiryDate < now.Date || batchStatus == "EXPIRED") return "Expired";
            if (quantityMilli <= 0) return "Out of stock";
            if (thresholdMilli > 0 && usableTotalMilli <= thresholdMilli) return "Low stock";
            return "Available";
        }

        private static string NormalizeName(string value)
        {
            return string.Join(" ", value.Trim().Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)).ToUpperInvariant();
        }

        private static object Db(string value) { return string.IsNullOrWhiteSpace(value) ? (object)DBNull.Value : value.Trim(); }
        private static long MultiplyMoney(long quantityMilli, long pricePaise)
        {
            return checked((long)Math.Round((decimal)quantityMilli * pricePaise / 1000m, 0, MidpointRounding.AwayFromZero));
        }
        private static string FormatMoney(long paise) { return (paise / 100m).ToString("N2", CultureInfo.GetCultureInfo("en-IN")); }
        private static string FormatQuantity(long quantityMilli) { return (quantityMilli / 1000m).ToString("0.###", CultureInfo.InvariantCulture); }
    }
}