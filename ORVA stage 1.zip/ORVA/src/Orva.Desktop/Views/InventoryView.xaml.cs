using System;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using Orva.Infrastructure;

namespace Orva.Views
{
    public partial class InventoryView : UserControl
    {
        public InventoryView()
        {
            InitializeComponent();
            RefreshInventory();
        }

        private void RefreshInventory()
        {
            InventoryGrid.ItemsSource = App.Services.InventoryRepository.GetInventoryRows(SearchBox == null ? string.Empty : SearchBox.Text);
            MedicineCountText.Text = App.Services.InventoryRepository.GetMedicineCount().ToString("N0");
            BatchCountText.Text = App.Services.InventoryRepository.GetBatchCount().ToString("N0");
            try
            {
                var path = App.Services.SnapshotWriter.GetSnapshotPath();
                var dirty = App.Services.SnapshotWriter.IsDirty();
                if (dirty)
                {
                    SnapshotStatusText.Text = "Needs refresh";
                    SnapshotStatusText.Foreground = (System.Windows.Media.Brush)FindResource("Danger");
                }
                else
                {
                    SnapshotStatusText.Text = File.Exists(path) ? "Updated" : "Not created yet";
                    SnapshotStatusText.Foreground = File.Exists(path) ? (System.Windows.Media.Brush)FindResource("Success") : (System.Windows.Media.Brush)FindResource("Muted");
                }
            }
            catch
            {
                SnapshotStatusText.Text = "Not available";
            }
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) { RefreshInventory(); }

        private void AddStock_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new AddStockWindow();
            dialog.Owner = Window.GetWindow(this);
            if (dialog.ShowDialog() == true) RefreshInventory();
        }

        private void RefreshSnapshot_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                App.Services.SnapshotWriter.WriteCurrentSnapshot();
                RefreshInventory();
                MessageBox.Show("The portable stock file has been updated.", "ORVA", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("The stock file could not be updated. Your saved inventory has not been changed. " + ex.Message,
                    "ORVA — Stock file", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void OpenFolder_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var shop = App.Services.ShopRepository.GetProfile();
                var folder = AppPaths.GetShopFolder(shop.ShopName);
                Directory.CreateDirectory(folder);
                Process.Start(new ProcessStartInfo { FileName = folder, UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("The shop folder could not be opened. " + ex.Message, "ORVA", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}