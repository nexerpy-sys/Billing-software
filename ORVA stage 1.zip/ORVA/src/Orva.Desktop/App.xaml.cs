using System;
using System.Windows;
using Orva.Infrastructure;
using Orva.Infrastructure.Database;
using Orva.Infrastructure.Repositories;
using Orva.Services;
using Orva.Services.Billing;
using Orva.Views;

namespace Orva
{
    public partial class App : Application
    {
        public static AppServices Services { get; private set; }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            try
            {
                AppPaths.EnsureDirectories();

                var database = new SqliteDatabase(AppPaths.DatabasePath);
                new DatabaseMigrator(database).Migrate();

                var shopRepository = new ShopRepository(database);
                var inventoryRepository = new InventoryRepository(database);
                var taxSettingsRepository = new TaxSettingsRepository(database);
                var snapshotWriter = new StockSnapshotWriter(database, shopRepository);
                var stockEntryService = new StockEntryService(inventoryRepository, snapshotWriter);
                var appSettings = new AppSettingsRepository(database);
                var billingService = new BillingService(database, snapshotWriter);

                Services = new AppServices(
                    database,
                    shopRepository,
                    inventoryRepository,
                    taxSettingsRepository,
                    stockEntryService,
                    snapshotWriter,
                    appSettings,
                    billingService);

                LocalizationManager.SetLanguage(appSettings.Get("display_language", "en"));

                if (shopRepository.GetProfile() == null)
                {
                    var setup = new ShopSetupWindow(shopRepository);
                    if (setup.ShowDialog() != true)
                    {
                        Shutdown();
                        return;
                    }
                }

                try
                {
                    Services.SnapshotWriter.WriteCurrentSnapshot();
                }
                catch
                {
                    // A snapshot failure must not prevent normal offline billing.
                }

                var main = new MainWindow();
                MainWindow = main;
                main.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "ORVA could not start because its local data could not be opened.\n\n" + ex.Message +
                    "\n\nYour existing business data has not been intentionally deleted. Please contact support if this continues.",
                    "ORVA — Startup problem",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                Shutdown(-1);
            }
        }
    }
}