using Orva.Domain.Billing;
using Orva.Infrastructure.Database;
using Orva.Infrastructure.Repositories;
using Orva.Services;

namespace Orva
{
    public sealed class AppServices
    {
        public SqliteDatabase Database { get; private set; }
        public ShopRepository ShopRepository { get; private set; }
        public InventoryRepository InventoryRepository { get; private set; }
        public TaxSettingsRepository TaxSettingsRepository { get; private set; }
        public StockEntryService StockEntryService { get; private set; }
        public StockSnapshotWriter SnapshotWriter { get; private set; }
        public AppSettingsRepository AppSettings { get; private set; }
        public IBillingService BillingService { get; private set; }

        public AppServices(
            SqliteDatabase database,
            ShopRepository shopRepository,
            InventoryRepository inventoryRepository,
            TaxSettingsRepository taxSettingsRepository,
            StockEntryService stockEntryService,
            StockSnapshotWriter snapshotWriter,
            AppSettingsRepository appSettings,
            IBillingService billingService)
        {
            Database = database;
            ShopRepository = shopRepository;
            InventoryRepository = inventoryRepository;
            TaxSettingsRepository = taxSettingsRepository;
            StockEntryService = stockEntryService;
            SnapshotWriter = snapshotWriter;
            AppSettings = appSettings;
            BillingService = billingService;
        }
    }
}