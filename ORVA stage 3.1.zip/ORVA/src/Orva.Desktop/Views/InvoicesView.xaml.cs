using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.Win32;
using Orva.Domain.Billing;
using Orva.Services;
using Orva.Services.Billing;
using Orva.ViewModels;

namespace Orva.Views
{
    public partial class InvoicesView : UserControl
    {
        private IList<SalesRegisterRow> _rows = new List<SalesRegisterRow>();

        public InvoicesView()
        {
            InitializeComponent();
            Loaded += (s, e) => RefreshList();
        }

        private void RefreshList()
        {
            if (App.Services == null) return;
            var selected = StatusFilterCombo.SelectedItem as ComboBoxItem;
            string status = selected != null ? Convert.ToString(selected.Content) : "ALL";
            _rows = App.Services.ReportingService.GetSalesRegister(
                FromDatePicker.SelectedDate,
                ToDatePicker.SelectedDate,
                status,
                SearchBox.Text);
            InvoicesGrid.ItemsSource = _rows;

            long activeTotal = 0;
            int activeCount = 0;
            for (int i = 0; i < _rows.Count; i++)
            {
                if (!string.Equals(_rows[i].Status, "CANCELLED", StringComparison.OrdinalIgnoreCase))
                {
                    activeTotal += _rows[i].GrandTotalPaise;
                    activeCount++;
                }
            }
            StatusText.Text = _rows.Count + " invoice(s) | " + activeCount + " active (Rs. " + InvoiceCalculator.FormatRupees(activeTotal) + ")";
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            RefreshList();
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) RefreshList();
        }

        private void StatusFilterCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (IsLoaded) RefreshList();
        }

        private void ReprintInvoice_Click(object sender, RoutedEventArgs e)
        {
            var row = InvoicesGrid.SelectedItem as SalesRegisterRow;
            if (row == null)
            {
                StatusText.Text = "Select an invoice to reprint.";
                return;
            }

            try
            {
                var record = App.Services.ReportingService.GetInvoiceForReprint(row.InvoiceId);
                if (record == null)
                {
                    StatusText.Text = "Invoice details could not be loaded.";
                    return;
                }

                var shop = App.Services.ShopRepository.GetProfile();
                var header = BillingShopHeader.FromProfile(shop);
                InvoicePaperFormat format = App.Services.InvoicePrintService.GetDefaultPaperFormat();

                var printResult = App.Services.InvoicePrintService.PrintInvoice(
                    record.CommittedInvoice,
                    record.Preview,
                    format,
                    header,
                    record.CustomerName,
                    record.CustomerPhone,
                    record.CustomerAddress,
                    record.CustomerGstin,
                    record.Tenders);

                if (printResult.Printed)
                    StatusText.Text = "Reprinted " + row.InvoiceNumber + " on " + printResult.PrinterName + ".";
                else if (printResult.CancelledByUser)
                    StatusText.Text = "Reprint cancelled.";
                else
                    StatusText.Text = printResult.ErrorMessage;
            }
            catch (Exception ex)
            {
                StatusText.Text = "Reprint failed: " + ex.Message;
            }
        }

        private void CancelInvoice_Click(object sender, RoutedEventArgs e)
        {
            var row = InvoicesGrid.SelectedItem as SalesRegisterRow;
            if (row == null)
            {
                StatusText.Text = "Select an invoice to cancel.";
                return;
            }

            string reason = (CancelReasonBox.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(reason))
            {
                StatusText.Text = "Enter a cancellation reason before cancelling.";
                CancelReasonBox.Focus();
                return;
            }

            var confirm = MessageBox.Show(
                "Cancel invoice " + row.InvoiceNumber + " (Rs. " + row.GrandTotalText + ")?\n\n" +
                "Reason: " + reason + "\n" +
                "The invoice record will be kept as CANCELLED in your archive and deducted batch stock will be restored.",
                "Confirm Invoice Cancellation",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);
            if (confirm != MessageBoxResult.Yes) return;

            try
            {
                var result = App.Services.InvoiceCancellationService.CancelInvoice(row.InvoiceId, reason, restoreStock: true);
                if (!result.Succeeded)
                {
                    StatusText.Text = result.ErrorMessage;
                    return;
                }

                CancelReasonBox.Text = string.Empty;
                RefreshList();
                StatusText.Text = "Invoice " + result.InvoiceNumber + " cancelled"
                    + (result.StockRestored ? " and batch stock restored." : ".")
                    + (string.IsNullOrWhiteSpace(result.SnapshotWarning) ? string.Empty : " (" + result.SnapshotWarning + ")");
            }
            catch (Exception ex)
            {
                StatusText.Text = "Cancellation failed: " + ex.Message;
            }
        }

        private void ExportCsv_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog
            {
                Title = "Export Sales Register CSV",
                Filter = "CSV files (*.csv)|*.csv",
                FileName = "ORVA_SalesRegister_" + DateTime.Now.ToString("yyyyMMdd") + ".csv"
            };
            if (dlg.ShowDialog() != true) return;
            try
            {
                App.Services.ReportingService.ExportSalesRegisterCsv(dlg.FileName, _rows);
                StatusText.Text = "Exported Sales Register CSV to " + dlg.FileName;
            }
            catch (Exception ex)
            {
                StatusText.Text = "Export failed (close the file if open in Excel): " + ex.Message;
            }
        }

        private void ExportXlsx_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog
            {
                Title = "Export Sales Register Excel",
                Filter = "Excel files (*.xlsx)|*.xlsx",
                FileName = "ORVA_SalesRegister_" + DateTime.Now.ToString("yyyyMMdd") + ".xlsx"
            };
            if (dlg.ShowDialog() != true) return;
            try
            {
                App.Services.ReportingService.ExportSalesRegisterXlsx(dlg.FileName, _rows);
                StatusText.Text = "Exported Sales Register Excel to " + dlg.FileName;
            }
            catch (Exception ex)
            {
                StatusText.Text = "Export failed (close the file if open in Excel): " + ex.Message;
            }
        }
    }
}
