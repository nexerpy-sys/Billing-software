using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Orva.Services;

namespace Orva.Views
{
    public partial class SubscriptionView : UserControl
    {
        private string _selectedPlan = "Monthly";

        public SubscriptionView()
        {
            InitializeComponent();
            LoadState();
        }

        private void LoadState()
        {
            var settings = App.Services.AppSettings;
            UsernameBox.Text = settings.Get(SubscriptionService.UsernameKey, string.Empty);
            ActivationCodeBox.Text = settings.Get(SubscriptionService.ActivationCodeKey, string.Empty);
            RegistryUrlBox.Text = settings.Get(SubscriptionService.RegistryUrlKey, string.Empty);

            string phones = settings.Get(SubscriptionService.SupportPhonesKey, "Configure support phone in Settings");
            string upiId = settings.Get(SubscriptionService.UpiIdKey, "Configure merchant UPI ID in Settings");
            string payee = settings.Get(SubscriptionService.UpiPayeeKey, string.Empty);
            string upiDisplay = string.IsNullOrWhiteSpace(payee) ? upiId : (upiId + " · Payee: " + payee);
            SupportContactText.Text = "1. Call Subscription Support: " + phones + "\n2. Pay via UPI (" + upiDisplay + ") — verified manually by Rindle Works admins.";

            RenderStatus(App.Services.SubscriptionService.EvaluateLocalStatus());
        }

        private void RenderStatus(SubscriptionStatus status)
        {
            PlanTitleText.Text = string.IsNullOrWhiteSpace(status.Plan) ? status.Status : status.Plan + " — " + status.Status;
            PlanDetailText.Text = status.Message;
        }

        private void SelectPlan_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            if (btn == null || btn.Tag == null) return;
            _selectedPlan = btn.Tag.ToString();
            SelectedPlanLabel.Text = "Selected plan: " + _selectedPlan;
        }

        private void NotifyWhatsapp_Click(object sender, RoutedEventArgs e)
        {
            var profile = App.Services.ShopRepository.GetProfile();
            string shopName = profile != null ? profile.ShopName : "Medical Shop";
            string waDigits = App.Services.AppSettings.Get(SubscriptionService.SupportWhatsappKey, string.Empty);

            string url = SubscriptionService.BuildWhatsAppClickToChatUrl(
                waDigits,
                shopName,
                UsernameBox.Text,
                _selectedPlan,
                AmountBox.Text,
                UtrBox.Text);

            try
            {
                Process.Start(new ProcessStartInfo { FileName = url, UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show(Window.GetWindow(this), "Could not open WhatsApp link: " + ex.Message, "ORVA", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void SaveCredentials_Click(object sender, RoutedEventArgs e)
        {
            App.Services.SubscriptionService.SaveCredentials(UsernameBox.Text, ActivationCodeBox.Text, RegistryUrlBox.Text);
            SaveStatusText.Foreground = (Brush)FindResource("Success");
            SaveStatusText.Text = "Licence settings saved. Click Refresh Subscription when online.";
            RenderStatus(App.Services.SubscriptionService.EvaluateLocalStatus());
        }

        private async void Refresh_Click(object sender, RoutedEventArgs e)
        {
            RefreshSubButton.IsEnabled = false;
            try
            {
                var status = await App.Services.SubscriptionService.RefreshFromRegistryAsync();
                RenderStatus(status);
            }
            finally
            {
                RefreshSubButton.IsEnabled = true;
            }
        }
    }
}
