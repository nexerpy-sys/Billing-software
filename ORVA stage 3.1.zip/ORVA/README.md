# ORVA — Pharmacy Billing & Inventory

**A product by Rindle Works** (working brand; legal/trademark clearance pending).

## Current scope

- Reusable commercial Windows desktop application for independent medical shops.
- One local SQLite database per shop installation.
- Windows 10 target; WPF, C# 7.3, .NET Framework 4.8.1 baseline.
- Offline daily billing and inventory; no Android app in current V1, no cloud business-data database and no device synchronisation.
- Ordinary unencrypted database and backups by explicit product decision.
- Invoice formats: 58 mm, 80 mm, A4 and A5.
- USB barcode scanner support and manual search fallback.
- Each shop configures its own profile, stock, print settings and invoice settings.

## Non-negotiable UX requirement

Design every workflow for the actual owner and staff described in the planning conversation: professional wording, minimum typing and decisions, no unnecessary prompts, comfortable readable controls, clear error messages, and no technical setup during routine billing. This must guide engineering and visual decisions equally.

## Current permanent foundation in source

- WPF application shell and theme resources.
- First-run shop profile setup.
- SQLite initial schema and migration runner.
- Shop and inventory repositories.
- Add Stock and Inventory screens.
- Transactional stock receipt logic.
- Automatic `StockData.json` snapshot writer (format `ORVA_STOCK_DATA`, version 1).
- English/Bengali resource dictionaries and persisted local language preference.
- Basic build/installer scaffolding.

## Not yet implemented

- Invoice/billing engine and complete billing screen.
- Payment capture UI.
- Sales return and invoice cancellation workflows.
- Complete `ShopBackup.shopbackup` creation/verification/restore.
- `StockData.json` import/preview/replacement.
- Reports/records exports.
- Printer integration for 58 mm, 80 mm, A4 and A5.
- USB barcode scanner integration.
- Subscription/activation UI and online GitHub licence lookup.
- Production installer validation and full regression suite.

## Portable files

- `StockData.json` is an automatically updated inventory snapshot. It is not the source of truth and is not a complete backup.
- `ShopBackup.shopbackup` is intended to contain the complete business database and metadata for migration/recovery.
- Both are unencrypted. Imports/restores must validate, preview, create a safety copy and require confirmation. Inventory imports must never delete historical invoices, payments, purchases, returns or audit history.

## Development status

The current source is an early permanent application foundation. It has **not yet been compiled and tested on the client's Windows 10 machine**. Do not treat source presence as a successful Windows build. Target verification requires Visual Studio/MSBuild and the .NET Framework 4.8.1 targeting pack on Windows.

See `AI_COLLABORATION_CONTEXT.md` for the authoritative product requirements and coding constraints.

## Billing implementation boundary

The shared backend/UI contract is in `docs/BILLING_UI_BACKEND_CONTRACT_v1.md` and the corresponding C# types are in `src/Orva.Desktop/Domain/Billing/BillingContracts.cs`.

Current AI task ownership:
- Gemini: billing domain/service, money and tax arithmetic, FEFO allocation, SQLite atomicity and backend tests.
- Qwen: native WPF billing interface, dynamic cart, payment UI and live on-screen paper preview.
- ChatGPT: integration, application service registration, main navigation, project wiring and final verification.

The contract is frozen for these parallel tasks. Do not add web technologies or allow UI code to calculate authoritative totals.